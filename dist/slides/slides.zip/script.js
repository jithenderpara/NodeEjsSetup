getClientinfo($("#leadid").val());
function IntroductionBind() {
  $(function() {
    if (clientdata) {

      //Introduction.html
      let data = clientdata;
      var _data2 =JSON.parse(clientdata.salesToolData);
      _data2 =JSON.parse(_data2);
      var termsUsed=JSON.parse(_data2["termsUsed"])
      $("#todaydate").html(new Date().toDateString());
      $("#ApplicantName, #applicant_name strong").html(termsUsed.ApplicantName);
      $("#LawFirm, #law_firm strong").html(termsUsed.LawFirm);


      $("#Credircard .item").click(function(){
        $("#Credircard .item").removeClass("active")
         $("#Credircard .item").addClass("inactive")
        $(this).addClass("active visiteditem")
      })
      

    }
    // else {
    // 	toastr.warning(data.message, { timeOut: 5000 })
    // }
    //End Introduction.html

    // //Current_financial_path
    // var _clientData = JSON.parse(data.clientData);
    // var _projectedPayOff = JSON.parse(data.projectedPayOff);
    // var _velocifyData = JSON.parse(data.velocifyData);
    // $("#total_debt").html(_clientData.Balance);
    // $("#current_interestrate").html(_clientData.projectedPayOff.interestRate);
    // $("#current_payment").html(_clientData.PaymentDue);
    // $("#pay_off_balance").html(_clientData.projectedPayOff);
    // $("#interest_paid").html(_clientData.projectedPayOff.ExtraInterestPaid);
    // $("#total_amount_paid").html(_clientData.projectedPayOff.ProjectedTotalPaid);
    //End Current_financial_path
  });
}

function loadCurrent_financial_path(){
  $(function(){
  var salesToolData=JSON.parse(clientdata.salesToolData)
  salesToolData=JSON.parse(salesToolData)
  var velocifyIncome=salesToolData.velocifyIncome
  velocifyIncome=JSON.parse(velocifyIncome)
  
  var total=salesToolData.total
    
    $("#current_bal").html(salesToolData.projectedPayOff.TotalUnsecuredDebt)
    $("#current_interestrate").html(salesToolData.projectedPayOff.InterestRate)
    $("#current_payment").html(total.TotalPaymentDue)
    $("#pay_off_balance").html(salesToolData.projectedPayOff.ProjectedPayOff)
    $("#interest_paid").html(salesToolData.projectedPayOff.ExtraInterestPaid)
    $("#total_amount_paid").html(salesToolData.projectedPayOff.ProjectedTotalPaid)
   $("#ficoScore").html(velocifyIncome["CreditData.FicoScore"])
   
  })

}
function loadprogram_conditions(){
  $(function(){
    $(".item").click(function () {
  $(".item").removeClass("active")
  $(".item").addClass("inactive")
  $(this).addClass("active")
})

})

}
function loadyourFinancialGoals(){
  $(function(){
    var _goals=[
  { ReturnedName :"You would like to take a vacation", MapTo :"Youwouldliketotakeavacation" },
  { ReturnedName :"You want to buy a car", MapTo :"Youwanttobuyacar" },
  { ReturnedName :"You want to help a loved one", MapTo :"Youwanttohelpalovedone" },
  { ReturnedName :"You would like to make some home improvements / renovations", MapTo :"Youwouldliketomakesomehomeimprovementsrenovations" },
  { ReturnedName :"You would like to upgrade your living situation", MapTo :"Youwouldliketoupgradeyourlivingsituation" },
  { ReturnedName :"You would like to use the money to invest", MapTo :"Youwouldliketousethemoneytoinvest" },
  { ReturnedName :"You want monthly payment relief", MapTo :"Youwantmonthlypaymentrelief" },
  { ReturnedName :"You want to get out of debt faster", MapTo :"Youwanttogetoutofdebtfaster" },
  { ReturnedName :"You would like to lower your interest rates", MapTo :"Youwouldliketoloweryourinterestrates" },
  { ReturnedName :"You want to stop living paycheck to paycheck", MapTo :"Youwanttostoplivingpaychecktopaycheck" },
  { ReturnedName :"Save money for retirement", MapTo :"Savemoneyforretirement" },
  { ReturnedName :"Put money away for your child's education", MapTo :"Putmoneyawayforyourchildseducation" },
  { ReturnedName :"Save money for unexpected expenses", MapTo :"Savemoneyforunexpectedexpenses" },
  { ReturnedName :"Unspecified Goal", MapTo :"UnspecifiedGoal" }
    ]
    var clientInfo=JSON.parse(clientdata.salesToolData)
    clientInfo=JSON.parse(clientInfo)
        var _keyareasdata_velocify=clientInfo.velocifyIncome
        
        _keyareasdata_velocify=JSON.parse(_keyareasdata_velocify)
        _keyareasdata=JSON.parse(_keyareasdata_velocify.ApplicantScoring)
    console.log(_keyareasdata_velocify.Youwouldliketotakeavacation)
    var getgoals=_keyareasdata_velocify;
    debugger
    var gcount=0;
    var _goalsList="";
    if(_goals.length>0){
      for (let index = 0; index < _goals.length; index++) {
      var _mapvalue=_goals[index].MapTo
      if(getgoals[_mapvalue]=="True"){
        _goalsList+="<li>"+_goals[index].ReturnedName+"</li>";
        gcount++;
      }    
          
    }
    if(getgoals.UnspecifiedGoal!=""){
      _goalsList+="<li>"+getgoals.UnspecifiedGoal+"</li>"
    }
    $("#clientgoals").html(_goalsList)
    }
    else{
      $("#nogoals").show();
    }
    if(gcount<=0){
      $("#nogoals").show();
    }
    if(_keyareasdata.length>0){
    var keyarealist="";
    for (let index = 0; index < _keyareasdata.length; index++) {
      const element = _keyareasdata[index];
      keyarealist+="<li>"+element+"</li>"
      
    }
    $("#keyareas").html(keyarealist)
  }
  else{
    $("#nokeyarea").show();
  }
  
  })
}
function loadyouranalysis(){

    
  $(function () {
    if (clientdata) {
      debugger
      var salesToolData=JSON.parse(clientdata.salesToolData)
      salesToolData=JSON.parse(salesToolData)
      var velocifyIncome=salesToolData.velocifyIncome
      velocifyIncome=JSON.parse(velocifyIncome)
      var total=salesToolData.total
      salesToolData=JSON.parse(salesToolData.clientData)
      console.log(velocifyIncome)
      var _HouseholdIncome=(parseFloat(velocifyIncome.HouseholdIncome))/12,
      cashflow=0,stateddti=0;HouseholdIncome=0;
      
      cashflow=parseFloat(velocifyIncome.HouseholdIncome)/12-((parseInt(total.TotalPaymentDue.split("$")[1]))+parseFloat(velocifyIncome.ApplicantMonthlyExpenses))
      stateddti=(parseInt(velocifyIncome.ApplicantMonthlyExpenses)/(parseFloat(velocifyIncome.HouseholdIncome/12)))
      stateddti=parseFloat(stateddti).toFixed(2)
      $("#income").html("$ "+_HouseholdIncome.toFixed(2))
      $("#expenses").html("$ "+velocifyIncome.ApplicantMonthlyExpenses)
      $("#cashflow").html("$ "+cashflow.toFixed(2))
      $("#stateddti").html(stateddti*100+"%")
      $("#total_debt").html(total.TotalBalances)
      $("#total").html(total.TotalBalances)
      $("#total_payments").html(total.TotalPaymentDue)
      $("#creditor").html(clientdata.salesToolData.Creditor)

var Creditor=JSON.parse(clientdata.tradelinedata)
var _tableTr="";
for (let index = 0; index < Creditor.length; index++) {
_tableTr+="<tr><td>"+Creditor[index].Creditor+"</td><td>"+Creditor[index].Balance+"</td></tr>"

}
_tableTr+='<tr style="color:#1c4889; font-size:20px;border-bottom:2px solid #1c4889;">\
                    <th style="">TOTAL</th>\
                    <th id ="total">'+total.TotalBalances+'</th>\
                  </tr>\
                  <tr style="color:#1c4889; font-size:20px;">\
                      <th >Total Payments</th>\
                      <th id ="total_payments">'+total.TotalPaymentDue+'</th>\
                    </tr>'
$("#tablebind").html(_tableTr)

    }
    
  })
}